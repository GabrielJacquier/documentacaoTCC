package tcc;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		ExtratorOntologia extrator = new ExtratorOntologia();
		extrator.extract();
	}

}
